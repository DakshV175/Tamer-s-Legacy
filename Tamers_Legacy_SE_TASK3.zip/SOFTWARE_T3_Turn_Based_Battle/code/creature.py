from settings import *
from random import sample

class Entity: #class for data from each creature
    def get_data(self, name):
        self.type = CREATURE_INFO[name]['type'] 
        self._health = self.max_health = CREATURE_INFO[name]['health']
        self.attacks = sample(list(ATTACKS_INFO.keys()),4)
        self.name = name

    @property
    def health(self):
        return self._health
    
    @health.setter
    def health(self, value):
        self._health = min(self.max_health, max(0, value))


class Creature(pygame.sprite.Sprite, Entity):
    def __init__(self, name, surf):
        super().__init__()
        self.image = surf
        self.rect = self.image.get_frect(bottomleft = (100, WINDOW_HEIGHT))
        self.get_data(name)

    def __repr__(self):
        return f'{self.name}: {self.health}/{self.max_health}'

class Opponent(pygame.sprite.Sprite, Entity):
    def __init__(self, name, surf, groups):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_frect(midbottom = (WINDOW_WIDTH - 300, 400))
        self.get_data(name)