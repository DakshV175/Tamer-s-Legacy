from settings import *

class UserInterface:
    def __init__(self, creature, player_creatures, mini_sprites_surfs, get_input):
        self.display_surface = pygame.display.get_surface()
        self.font = pygame.font.Font(None, 30)
        self.left = WINDOW_WIDTH / 2 - 100
        self.top = WINDOW_HEIGHT / 2 + 50
        self.creature = creature
        self.mini_sprites_surfs = mini_sprites_surfs
        self.get_input = get_input

        #control section for attributes in menus
        self.general_options = ['attack', 'heal', 'switch', 'escape']
        self.general_index = {'col': 0, 'row': 0}
        self.attack_index = {'col': 0, 'row': 0}
        self.state = 'general'
        self.rows, self.cols = 2,2
        self.visible_creatures = 4
        self.player_creatures = player_creatures
        self.available_creatures = [creature for creature in self.player_creatures if creature != self.creature and creature.health > 0]
        self.switch_index = 0
       

    def input(self):
        keys = pygame.key.get_just_pressed() 
        if self.state == 'general':
            self.general_index['row'] = (self.general_index['row'] + int(keys[pygame.K_DOWN]) - int(keys[pygame.K_UP])) % self.rows # % self.rows limits to two rows
            self.general_index['col'] = (self.general_index['col'] + int(keys[pygame.K_RIGHT]) - int(keys[pygame.K_LEFT])) % self.cols# % self.cols limits to two columns
            if keys[pygame.K_SPACE]:
                self.state = self.general_options[self.general_index['col'] + self.general_index['row'] * 2]
        
        elif self.state == 'attack': #Attack button Menu
            self.attack_index['row'] = (self.attack_index['row'] + int(keys[pygame.K_DOWN]) - int(keys[pygame.K_UP])) % self.rows # % self.rows limits to two rows
            self.attack_index['col'] = (self.attack_index['col'] + int(keys[pygame.K_RIGHT]) - int(keys[pygame.K_LEFT])) % self.cols# % self.cols limits to two columns
            if keys[pygame.K_SPACE]:
                attack = self.creature.attacks[self.attack_index['col'] + self.attack_index['row'] * 2]
                self.get_input(self.state, attack)
                self.state = 'general'
        
        elif self.state == 'switch':
            if self.available_creatures:
                self.switch_index = (self.switch_index + int(keys[pygame.K_DOWN]) - int(keys[pygame.K_UP])) % len(self.available_creatures)
                if keys[pygame.K_SPACE]:
                    self.get_input(self.state, self.available_creatures[self.switch_index])
                    self.state = 'general'

        elif self.state == 'heal':
            self.get_input('heal')
            self.state = 'general'

        elif self.state == 'escape':
            self.get_input('escape')

        
        if keys[pygame.K_ESCAPE]:
            self.state = 'general'
            self.general_index = {'col': 0, 'row': 0}
            self.attack_index = {'col': 0, 'row': 0}
            self.switch_index = 0


    def quad_selection(self, index, options):
        #Background of Menu
        rect = pygame.FRect(self.left + 40, self.top + 60,400,200)
        pygame.draw.rect(self.display_surface,COLOURS['white'],rect, 0, 4)
        pygame.draw.rect(self.display_surface,COLOURS['gray'],rect, 4, 4)

        #Menu button options
        for col in range(self.cols):
            for row in range(self.rows):
                x = rect.left + rect.width / (self.cols * 2) + (rect.width / self.cols) * col
                y = rect.top + rect.height / (self.rows * 2) + (rect.height / self.rows) * row
                i = col + 2 * row
                colour = COLOURS['gray'] if col == index['col'] and row == index['row'] else COLOURS['black']
                text_surf = self.font.render(options[i], True, colour)
                text_rect = text_surf.get_frect(center = (x,y))
                self.display_surface.blit(text_surf, text_rect)

    def stats(self):
        #background for stats
        rect = pygame.FRect(self.left, self.top, 250, 80)
        pygame.draw.rect(self.display_surface,COLOURS['white'],rect, 0, 4)
        pygame.draw.rect(self.display_surface,COLOURS['gray'],rect, 4, 4)

        #info in stats
        name_surf = self.font.render (self.creature.name, True, COLOURS['black'])
        name_rect = name_surf.get_frect(topleft = rect.topleft + pygame.Vector2(rect.width * 0.05, 12))
        self.display_surface.blit(name_surf, name_rect)

        #The healthbar
        health_rect = pygame.FRect(name_rect.left, name_rect.bottom + 10, rect.width * 0.9, 20)
        pygame.draw.rect(self.display_surface, COLOURS['gray'], health_rect)
        self.draw_bar(health_rect, self.creature.health, self.creature.max_health)

    def draw_bar(self, rect, value, max_value):
        ratio = rect.width / max_value
        progress_rect = pygame.FRect(rect.topleft, (value * ratio, rect.height))
        pygame.draw.rect(self.display_surface, COLOURS['red'], progress_rect)


    
    def update(self):
        self.input()
        self.available_creatures = [creature for creature in self.player_creatures if creature!= self.creature and creature.health > 0]

    def switch(self):
        #switch background of menu
        rect = pygame.FRect(self.left + 40, self.top - 140, 400, 400)
        pygame.draw.rect(self.display_surface,COLOURS['white'],rect, 0, 4)
        pygame.draw.rect(self.display_surface,COLOURS['gray'],rect, 4, 4)

        #switch menu
        v_offset = 0 if self.switch_index < self.visible_creatures else -(self.switch_index - self.visible_creatures + 1) * rect.height / self.visible_creatures
        for i in range(len(self.available_creatures)):
            x = rect.centerx
            y = rect.top + rect.height / (self.visible_creatures * 2) + rect.height / self.visible_creatures * i + v_offset
            colour = COLOURS['gray'] if i == self.switch_index else COLOURS['black']
            name = self.available_creatures[i].name 

            mini_sprites_surf = self.mini_sprites_surfs[name]
            mini_sprites_rect = mini_sprites_surf.get_frect(center = (x - 100,y))

            text_surf = self.font.render(name, True, colour)
            text_rect = text_surf.get_frect(midleft = (x,y))
            if rect.collidepoint(text_rect.center):
                self.display_surface.blit(text_surf, text_rect)
                self.display_surface.blit(mini_sprites_surf, mini_sprites_rect)


    def draw(self):
        match self.state:
            case 'general': self.quad_selection(self.general_index, self.general_options)
            case 'attack': self.quad_selection(self.attack_index, self.creature.attacks)
            case 'switch': self.switch()

        if self.state != 'switch':
            self.stats()


class OpponentUI:
    def __init__(self, creature):
        self.display_surf = pygame.display.get_surface()
        self.creature = creature
        self.font = pygame.font.Font(None, 30)

    def draw(self):
        #background for enemy ui
        rect = pygame.FRect((0,0), (250,80)).move_to(midleft = (500, self.creature.rect.centery))
        pygame.draw.rect(self.display_surf,COLOURS['white'],rect, 0, 4)
        pygame.draw.rect(self.display_surf,COLOURS['gray'],rect, 4, 4)

        name_surf = self.font.render(self.creature.name, True, COLOURS['black'])
        name_rect = name_surf.get_frect(topleft = rect.topleft + pygame.Vector2(rect.width * 0.05, 12))
        self.display_surf.blit(name_surf, name_rect)

        #health of enemy
        health_rect = pygame.FRect(name_rect.left, name_rect.bottom + 10, rect.width * 0.9, 20)
        ratio = health_rect.width / self.creature.max_health
        progress_rect = pygame.FRect(health_rect.topleft, (self.creature.health * ratio, health_rect.height))
        pygame.draw.rect(self.display_surf, COLOURS['gray'], health_rect)
        pygame.draw.rect(self.display_surf, COLOURS['red'], progress_rect)
