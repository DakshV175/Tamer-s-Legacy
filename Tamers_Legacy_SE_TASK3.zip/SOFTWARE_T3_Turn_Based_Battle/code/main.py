from settings import *
from support import *
from timer import Timer
from creature import *
from random import choice
from interface import *
from attack import AttackAnimationSprite

# The game class holding the main functions of the game
class Game:
    def __init__(self):
        pygame.init()
        self.display_surface = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption("Tamer's Legacy")
        self.clock = pygame.time.Clock()
        self.running = True
        self.import_assets()
        self.audio['music'].play(-1)
        self.player_active = True

        #Groups
        self.all_sprites = pygame.sprite.Group()

        #data of creatures
        player_creature_list = ['Mortle','Fronovale','Verleon','Seraphine','Florazor','Voltcoil']
        self.player_creatures = [Creature(name, self.back_surfs[name]) for name in player_creature_list]
        self.creature = self.player_creatures[0]
        self.all_sprites.add(self.creature)
        opponent_name = choice(list(CREATURE_INFO.keys()))
        self.opponent = Opponent(opponent_name, self.front_surfs[opponent_name], self.all_sprites)

        # User interface
        self.userinterface = UserInterface(self.creature, self.player_creatures, self.mini_sprites_surfs, self.get_input)
        self.opponent_ui = OpponentUI(self.opponent)

        # Timer Section
        self.timers = {'player end': Timer(1000, func = self.opponent_turn), 'opponent end': Timer(1000, func = self.player_turn)}
    
    def get_input(self, state, data = None):
        if state == 'attack':
            self.apply_attack(self.opponent, data)

        elif state == 'heal':
            self.creature.health += 40
            AttackAnimationSprite(self.creature, self.attack_frames['green'], self.all_sprites)
            self.audio['green'].play()

        elif state == 'switch':
            self.creature.kill()
            self.creature = data
            self.all_sprites.add(self.creature)
            self.userinterface.creature = self.creature

        elif state == 'escape':
            self.running = False
        self.player_active = False
        self.timers['player end'].activate()
    
    def apply_attack(self, target, attack):
        attack_info = ATTACKS_INFO[attack]
        attack_multiplier = TYPE_INFO[attack_info['type']][target.type] #attack type modifier
        target.health -= attack_info['damage'] * attack_multiplier
        AttackAnimationSprite(target, self.attack_frames[attack_info['animation']], self.all_sprites)
        self.audio[attack_info['animation']].play()

    def opponent_turn(self):
        if self.opponent.health <= 0:
            self.player_active = True
            self.opponent.kill()
            creature_name = choice(list(CREATURE_INFO.keys()))
            self.opponent = Opponent(creature_name, self.front_surfs[creature_name], self.all_sprites)
            self.opponent_ui.creature = self.opponent
        else:
            attack = choice(self.opponent.attacks)
            self.apply_attack(self.creature, attack)
            self.timers['opponent end'].activate()

    def player_turn(self):
        self.player_active = True
        if self.creature.health <= 0:
            available_creatures = [creature for creature in self.player_creatures if creature.health > 0]
            if available_creatures:
                self.creature.kill()
                self.creature = available_creatures[0]
                self.all_sprites.add(self.creature)
                self.userinterface.creature = self.creature
            else:
                self.running = False

    def update_timers(self):
        for timer in self.timers.values():
            timer.update()



    def import_assets(self):
        self.back_surfs = folder_import('images', 'sprite_backwards')
        self.front_surfs = folder_import('images', 'sprite_forwards')
        self.background_surfs = folder_import('images', 'background')
        self.mini_sprites_surfs = folder_import('images', 'mini_sprites')
        self.attack_frames = tile_import(4,'images', 'attack_animations')
        self.audio = audio_importer('sounds')

    def draw_creature_platform(self):
        for sprite in self.all_sprites:
            if isinstance(sprite, Entity):
                floor_rect = self.background_surfs['platform'].get_frect(center = sprite.rect.midbottom + pygame.Vector2(0, -10))
                self.display_surface.blit(self.background_surfs['platform'], floor_rect)

    def run(self):
        while self.running:
            dt = self.clock.tick() / 1000
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
            
            #Update
            self.update_timers()
            self.all_sprites.update(dt)
            if self.player_active:  
                self.userinterface.update()

            #Drawing background, platforms, sprites and user interface
            self.display_surface.blit(self.background_surfs['sceneryV2'], (0,0))
            self.draw_creature_platform()
            self.all_sprites.draw(self.display_surface)
            self.userinterface.draw()
            self.opponent_ui.draw()
            pygame.display.update()

        pygame.quit()

if __name__ == '__main__':
    game = Game()
    game.run()