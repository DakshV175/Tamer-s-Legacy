import pygame
from os.path import join
from os import walk

WINDOW_WIDTH = 1280 # The width of the game window
WINDOW_HEIGHT= 720 # The height of the game window

COLOURS = { # the colours used for fonts and rectangles in the game
    'black': '#000000',
    'red': '#ee1a0f',   
    'gray': 'gray',
    'white': '#ffffff'
}

CREATURE_INFO = { # The statistics of the creatures with type, health
    'Voltcoil': {'type': 'fire', 'health': 130},
    'Mortle': {'type': 'fire', 'health': 140},
    'Seraphine': {'type': 'water', 'health': 160},
    'Fronovale': {'type': 'water', 'health': 120},
    'Florazor': {'type': 'grass', 'health': 140},
    'Verleon': {'type': 'grass', 'health': 160}
}

ATTACKS_INFO = { #The statistics of the attacks, including damage, type, and animation
    'scratch': {'damage': 20, 'type': 'normal', 'animation': 'scratch'},
    'spark': {'damage': 35, 'type': 'fire', 'animation': 'fire'},
    'erupt': {'damage': 50, 'type': 'fire', 'animation': 'explosion'},
    'splash': {'damage': 30, 'type': 'water', 'animation': 'splash'},
    'shards': {'damage': 50, 'type': 'water', 'animation': 'ice'},
    'spiral': {'damage': 40, 'type': 'plant', 'animation': 'green'}
}

TYPE_INFO = { # The statistics of the types, including the damage multipler against different types
    'fire': {'water': 0.5, 'grass': 2, 'fire': 1, 'normal': 1},
    'plant': {'water': 2, 'grass': 1, 'fire': 0.5, 'normal': 1},
    'normal': {'water': 1, 'grass': 1, 'fire': 1, 'normal': 1},
    'water': {'water': 1, 'grass': 0.5, 'fire': 2, 'normal': 1}
}